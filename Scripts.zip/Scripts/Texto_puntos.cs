using UnityEngine;

public class Texto_puntos : MonoBehaviour
{
    private Puntuacion puntuacion;
    private int puntosActualizados = 0;
    public int puntosParaGanar = 100;
    public int timelimit = 1000;
    private int timepast = 1000;
    public GameObject objetoHijo;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        puntuacion = FindFirstObjectByType<Puntuacion>();

    }

    // Update is called once per frame
    void Update()
    {
        // muestra los puntos en la UI
        GetComponent<UnityEngine.UI.Text>().text = "Puntos: " + puntuacion.puntos.ToString();
        if (puntosActualizados != puntuacion.puntos) {
            if (puntuacion.puntos % puntosParaGanar == 0 ) {
                objetoHijo.SetActive(true);
            }
            puntosActualizados = puntuacion.puntos;
        }
        if (objetoHijo.activeSelf) {
            timepast -= 1;
            if (timepast <= 0) {
                objetoHijo.SetActive(false);
                timepast = timelimit;
            }
        }
    }

}
