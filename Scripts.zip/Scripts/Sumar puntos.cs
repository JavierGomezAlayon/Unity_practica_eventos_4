using UnityEngine;

public class Sumarpuntos : MonoBehaviour
{
    private Puntuacion puntuacion;
    public int puntosASumar = 1;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        puntuacion = FindFirstObjectByType<Puntuacion>();
    }
    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.CompareTag("Tipo1") || other.gameObject.CompareTag("Tipo2")) {
            puntuacion.puntos += puntosASumar;
            Debug.Log("Puntos: " + puntuacion.puntos);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
