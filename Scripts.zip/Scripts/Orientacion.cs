using UnityEngine;

public class Orientacion : MonoBehaviour
{
    public GameObject EscudoReference;
    private ColisionShieldReference colisionShieldReference;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        colisionShieldReference = FindFirstObjectByType<ColisionShieldReference>();
        colisionShieldReference.OnShieldCollision += ManejarColisionEscudo;
    }

    private void ManejarColisionEscudo()
    {
        transform.LookAt(EscudoReference.transform);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
