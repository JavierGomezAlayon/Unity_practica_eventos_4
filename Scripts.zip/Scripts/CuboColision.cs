using UnityEngine;

public class CuboColision : MonoBehaviour
{
    public delegate void mensaje();
    public event mensaje OnDisparadorTipo1;
    public event mensaje OnDisparadorTipo2;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.CompareTag("Tipo1")) {
            OnDisparadorTipo1();
        }
        else if (other.gameObject.CompareTag("Tipo2")) {
            OnDisparadorTipo2();
        }
    }
}
