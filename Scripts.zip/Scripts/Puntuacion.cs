using UnityEngine;

public class Puntuacion : MonoBehaviour
{
    // lo unico que hace este script es almacenar los puntos para que se pueda acceder a ellos desde otros scripts
    public int puntos = 0;
}
