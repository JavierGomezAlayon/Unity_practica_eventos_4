using UnityEngine;

public class Teleport : MonoBehaviour
{
    public GameObject EscudoReference;
    private ColisionShieldReference colisionShieldReference;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        colisionShieldReference = FindFirstObjectByType<ColisionShieldReference>();
        colisionShieldReference.OnShieldCollision += ManejarColisionEscudo;
    }

    private void ManejarColisionEscudo()
    {
        transform.position = EscudoReference.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
