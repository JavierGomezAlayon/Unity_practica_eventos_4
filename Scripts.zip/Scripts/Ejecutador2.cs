using UnityEngine;

public class Ejecutador2 : MonoBehaviour
{
    public GameObject TargetObject;
    public GameObject EscudoObject;
    private Disparador disparador;
    private CuboColision cuboColision;
    private GameObject objetoHijo;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        disparador = FindFirstObjectByType<Disparador>();
        cuboColision = FindFirstObjectByType<CuboColision>();
        disparador.OnDisparador += ManejarDisparador;
        cuboColision.OnDisparadorTipo2 += ManejarDisparador2;
        objetoHijo = transform.Find("FootmanMesh").gameObject;
    }

    private void ManejarDisparador()
    {
        int count = 0;
        while (count <= 200) {
            Vector3 direccion = TargetObject.transform.position - transform.position;
            direccion.Normalize();
            GetComponent<Rigidbody>().AddForce(direccion, ForceMode.Force);
            count++;
        }
    }
    private void ManejarDisparador2()
    {
        int count = 0;
        while (count <= 200) {
            Vector3 direccion = EscudoObject.transform.position - transform.position;
            direccion.Normalize();
            GetComponent<Rigidbody>().AddForce(direccion * 2, ForceMode.Force);
            count++;
        }
    }

    private void OnCollisionEnter(Collision other) {
        if (other.gameObject.CompareTag("Escudo2")) {
            if (objetoHijo != null) {
                objetoHijo.GetComponent<Renderer>().material.color = Color.green;
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
